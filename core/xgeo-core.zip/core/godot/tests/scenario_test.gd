## The end-to-end check of xGEO Core, on the TEST RANGE scenario
## (data/examples/test_range.json), headless, Core alone:
##   godot --headless --path godot --script res://tests/scenario_test.gd
## Where run_tests checks each model against its reference, this plays one
## world through every part of Core and checks that the parts agree:
## 1. The scenario loads: every ship, the station on its moon, the civil
##    emitter, the opening track.
## 2. Determinism: the same seed gives the same world; another seed does not.
## 3. Two days of flight stay physical: finite, outside Jupiter, orbits kept.
## 4. Sensing: bursts heard, classified, direction-found by two ears; the
##    track on the inspector stays honest (truth inside its own 4σ); Jupiter
##    hides the far ship.
## 5. Manoeuvre planning: a planned and refined transfer arrives.
## 6. Effects against their formulas: jam, dazzle (and the laser's heat), HPM,
##    Pk; each used once, each paid for in escalation.
## 7. A kill vehicle hits: the target breaks up, the debris objective fails.
## 8. The campaign: objectives, the end of the operation, the debrief.
## 9. Save and load give back the same world; the command-line runner writes
##    well-formed JSON lines; a finished world is freed.
## Thresholds are design values for a test, chosen with margin over what the
## models give; each is stated where it is checked.
extends SceneTree

const RANGE := "res://data/examples/test_range.json"
var fails := 0


func _check(ok: bool, what: String) -> void:
	print(("ok    " if ok else "FAIL  ") + what)
	if not ok:
		fails += 1


func _world(seed_ := -1) -> Sim:
	return Sim.new("res://data/game.json", RANGE, seed_)


## Put a ship beside another (offset km along its track, same velocity).
func _beside(sim: Sim, id: String, of: String, along_km: float) -> void:
	var o: Dictionary = sim.by_id[of]
	var u := V.scale(o.v, 1.0 / V.norm(o.v))
	sim.by_id[id].r = V.add(o.r, V.scale(u, along_km))
	sim.by_id[id].v = o.v.duplicate()


## A tight hostile track on a Red ship: what a good fix would give.
func _tight(sim: Sim, id: String) -> void:
	var h: Dictionary = sim.by_id[id]
	var tr := Track.new(id, "TRK %s" % h.short, PackedFloat64Array([h.r[0], h.r[1], h.v[0], h.v[1]]), Track.diag([0.5 ** 2, 0.5 ** 2, 0.001 ** 2, 0.001 ** 2]), sim.t)
	tr.side = "hostile"
	tr.ident = "classified"
	tr.class_id = h.classId
	sim.tracks[id] = tr


func _fingerprint(sim: Sim) -> String:
	var parts := []
	for s in sim.ships:
		parts.append("%s %.9f %.9f" % [s.id, s.r[0], s.r[1]])
	# By id: a loaded save gives the tracks back in another order, the same tracks.
	# (as plain strings: the opening track's key is a StringName, which sorts apart)
	var ids := sim.tracks.keys().map(func(k): return String(k))
	ids.sort()
	for id in ids:
		parts.append("%s %.6f %.6f" % [id, sim.tracks[id].x[0], sim.tracks[id].x[1]])
	parts.append(str(sim.log.map(func(e): return e.text)))
	return "\n".join(parts)


func _init() -> void:
	# 1. It loads.
	var sim := _world()
	for id in ["pelican", "lancer", "excal", "gstn", "h1", "h2", "c1"]:
		_check(sim.by_id.has(id), "%s is in the world" % id)
	var g: Array = sim.moon_state("ganymede", sim.t)
	_check(V.dist(sim.by_id.gstn.r, g[0]) < 1e-6, "Ganymede Station rides its moon")
	_check(sim.tracks.has("h1") and sim.tracks.h1.side != "neutral", "the opening track on the inspector is held")
	_check(sim.camp.name == "TEST RANGE" and sim.effects.cfg.has("jam"), "the scenario's effects block is read")

	# 2. Determinism.
	var a := _world()
	var b := _world()
	var c := _world(1)
	for w in [a, b, c]:
		w.advance(6.0 * Sim.HOUR)
	_check(_fingerprint(a) == _fingerprint(b), "the same seed gives the same world after 6 h, to the last digit")
	_check(_fingerprint(a) != _fingerprint(c), "another seed gives another world")
	a = null
	b = null
	c = null

	# 3-4. Two days of flight, the inspector's track watched as it goes.
	var R_J := float(sim.data.jupiter.radius)
	var r0 := V.norm(sim.by_id.pelican.r)
	var worst_sig := 0.0
	var worst_err := 0.0
	var finite := true
	var outside := true
	for i in 48:
		sim.advance(Sim.HOUR)
		for s in sim.ships:
			if not s.alive:
				continue
			finite = finite and is_finite(s.r[0]) and is_finite(s.r[1]) and is_finite(s.v[0]) and is_finite(s.v[1])
			outside = outside and V.norm(s.r) > R_J
		if sim.tracks.has("h1"):
			var tr: Track = sim.tracks.h1.forecast(sim.t)
			var err := V.dist(tr.pos(), sim.by_id.h1.r)
			var sig := maxf(tr.ellipse().major, 1e-9)
			if err / sig > worst_err / maxf(worst_sig, 1e-9):
				worst_err = err
				worst_sig = sig
	_check(finite, "every state stays finite over two days")
	_check(outside, "nothing falls inside Jupiter (%.0f km)" % R_J)
	# The weather satellite flies no manoeuvres: the moons and J2 move it, by far less than 2% in radius.
	_check(absf(V.norm(sim.by_id.pelican.r) / r0 - 1.0) < 0.02, "an unmanoeuvred orbit keeps its size (%.3f%%)" % (100.0 * absf(V.norm(sim.by_id.pelican.r) / r0 - 1.0)))
	# Track honesty: the truth inside 4σ of the belief, worst case over 48 looks (design threshold).
	_check(worst_sig > 0.0 and worst_err <= 4.0 * worst_sig, "the inspector's track stays honest: at worst %.3f km off at 1σ %.3f km" % [worst_err, worst_sig])

	print("  %d intercepts in two days" % sim.intercepts.size())
	_check(sim.intercepts.size() > 0, "bursts are heard")
	var two_ears := sim.intercepts.filter(func(r): return r.heard_by.size() >= 2)
	_check(not two_ears.is_empty(), "some bursts are heard by two ears (needed to fix a position)")
	if not two_ears.is_empty():
		# Fresh enough to direction-find: hear one now.
		var fresh := sim.intercepts.filter(func(r): return r.heard_by.size() >= 2 and not r.df and sim.t - float(r.end) <= float(sim.data.cfg.radio.recordSeconds))
		if fresh.is_empty():
			print("  (no unfixed two-ear burst inside the recording window at the end; DF checked on a new run)")
			var d := _world()
			while d.t < 2.0 * Sim.DAY and not d.intercepts.any(func(r): return r.heard_by.size() >= 2):
				d.advance(600.0)
			fresh = d.intercepts.filter(func(r): return r.heard_by.size() >= 2)
			_check(not fresh.is_empty() and d.sensing.df(fresh[0].id) >= 2, "direction-finding draws one line per ear")
		else:
			_check(sim.sensing.df(fresh[0].id) >= 2, "direction-finding draws one line per ear")
	var classified := sim.intercepts.any(func(r): return r.classified) or sim.intercepts.any(func(r): return sim.sensing.classify(r.id))
	_check(classified, "a strong burst is classified by its modulation")

	# Occultation: h2 sits on the far side of Jupiter from the Blue ships at the start.
	var o := _world()
	_check(o.sensing.occulted(o.by_id.lancer.r, o.by_id.h2.r), "Jupiter hides the far ship from LANCER")
	_check(not o.sensing.occulted(o.by_id.lancer.r, o.by_id.pelican.r), "and does not hide PELICAN-3, on the same side")

	# 5. Planning: a 90-minute transfer to the weather satellite (a third of an
	# orbit: single-revolution Lambert), refined, arrives (truth: it is ours).
	var p := _world()
	var plan := p.plan_intercept("lancer", "pelican", 1.5 * Sim.HOUR, true)
	_check(plan.get("ok", false), "a 90 min transfer to PELICAN-3 is planned (%.1f m/s)" % (float(plan.get("dv", 0.0)) * 1000.0))
	_check(p.execute(plan), "and flown")
	p.advance(1.5 * Sim.HOUR)
	var miss := p.range_km("lancer", "pelican")
	# 50 km: design threshold, as run_tests uses for an intercept.
	_check(miss < 50.0, "it arrives within 50 km (%.2f km)" % miss)

	# 6. Effects, against their own formulas.
	var e := _world()
	var cfg := e.effects.cfg
	var hr := e.effects.hpm_range_km()
	var hr_ref := sqrt(30.0 * float(cfg.hpm.peakW) * pow(10.0, float(cfg.hpm.gainDbi) / 10.0)) / float(cfg.hpm.upsetVm) / 1000.0
	_check(absf(hr / hr_ref - 1.0) < 1e-9, "HPM reach is √(30PG)/E: %.2f km" % hr)
	_check(absf(Effects.kill_probability(1.0, 1.0, 0.9) - 0.9 * (1.0 - exp(-0.5))) < 1e-12, "Pk is the Rayleigh CDF times reliability")
	var w := e.effects.laser(e.by_id.excal)
	_check(not w.is_empty(), "EXCALIBUR carries a laser")
	if not w.is_empty():
		var dz := e.effects.dazzle_range_km(w)
		_check(absf(e.effects.irradiance(w, dz) / float(cfg.dazzle.saturationWm2) - 1.0) < 0.01, "at the dazzle reach (%.0f km) the irradiance is the saturation level" % dz)
		_check(e.effects.irradiance(w, dz / 2.0) > e.effects.irradiance(w, dz), "closer is brighter")
	var jr := e.effects.jam_range_km(e.by_id.lancer, e.by_id.h1, float(cfg.jam.needJsDb))
	_check(jr > 0.0 and is_finite(jr), "LANCER's jammer has a reach on the inspector's link (%.0f km)" % jr)

	# Used: LANCER and EXCALIBUR beside the inspector with a tight track.
	_tight(e, "h1")
	_beside(e, "lancer", "h1", -minf(20.0, hr * 0.5))
	_beside(e, "excal", "h1", -30.0)
	var esc0 := e.escalation
	_check(e.effects.use("jam", "lancer", "h1"), "jam: on")
	e.advance(Sim.HOUR)
	_check(e.escalation > esc0, "jamming costs escalation by the hour (+%.1f)" % (e.escalation - esc0))
	_check(e.effects.use("jam", "lancer", "h1") and not e.effects.jamming.has("lancer"), "jam: off again")
	_tight(e, "h1")
	_beside(e, "excal", "h1", -30.0)
	var heat0 := float(e.by_id.excal.get("heat", {}).get("Q", 0.0))
	var dazzled := e.effects.use("dazzle", "excal", "h1")
	_check(dazzled, "dazzle from EXCALIBUR at 30 km")
	if dazzled:
		_check(float(e.by_id.h1.dazzled_until) > e.t, "the inspector is blind until %.1f h" % ((float(e.by_id.h1.dazzled_until) - e.t) / Sim.HOUR))
		e.advance(600.0)
		_check(float(e.by_id.excal.get("heat", {}).get("Q", 0.0)) > heat0, "the laser's waste heat reaches the radiators (Q %.0f → %.0f W)" % [heat0, float(e.by_id.excal.get("heat", {}).get("Q", 0.0))])
	_tight(e, "h1")
	_beside(e, "lancer", "h1", -minf(20.0, hr * 0.5))
	var esc1 := e.escalation
	_check(e.effects.use("hpm", "lancer", "h1") and e.by_id.h1.get("disabled", false), "HPM inside its reach disables the inspector")
	_check(absf(e.escalation - esc1 - float(cfg.hpm.escalation)) < 1e-9, "and costs its escalation (+%.0f)" % float(cfg.hpm.escalation))
	_check(e.campaign.neutralized(e.by_id.h1), "a disabled inspector counts as out of the fight")
	var h: Dictionary = e.by_id.h1
	_check(not e.effects.use("hpm", "pelican", "h1"), "a ship without the payload cannot fire it")

	# The burning engine shows in the IR: the thermal model's plume term.
	var lancer: Dictionary = e.by_id.lancer
	var toward := V.scale(lancer.r, -1.0)
	_check(float(e.thermal.intensity(lancer, toward, true).total) > float(e.thermal.intensity(lancer, toward, false).total), "a burning engine is brighter in the IR")

	# 7. Kill vehicles. On the 0.5 t inspector, from 3,000 km behind it: a catastrophic breakup.
	var k := _world()
	_beside(k, "lancer", "h1", -3000.0)
	_tight(k, "h1")
	_check(k.effects.use("kinetic", "lancer", "h1"), "a kill vehicle is fired at the inspector")
	var kv: Dictionary = k.effects.kvs.back()
	var t0 := k.t
	while not kv.done and k.t - t0 < 4.0 * Sim.HOUR:
		k.advance(60.0)
	_check(kv.result == "hit", "it hits (miss %.1f m)" % (float(kv.get("miss_km", -1.0)) * 1000.0))
	_check(not k.by_id.h1.alive and k.debris.size() == 1 and k.debris[0].cat, "the inspector breaks up into one debris cloud")
	# On the 60 t tender the same hit is not catastrophic (EMR under 40 J/g): cratered, still flying.
	var k2 := _world()
	_beside(k2, "lancer", "h2", -3000.0)
	_tight(k2, "h2")
	k2.effects.use("kinetic", "lancer", "h2")
	var kv2: Dictionary = k2.effects.kvs.back()
	while not kv2.done and k2.t - t0 < 4.0 * Sim.HOUR:
		k2.advance(60.0)
	_check(kv2.result == "hit" and k2.by_id.h2.alive and not k2.by_id.h2.get("damage", []).is_empty(), "on the 60 t tender it craters, not breaks up (lost: %s)" % Damage.describe(k2.by_id.h2.get("damage", [])))
	var deb := k.campaign.status().filter(func(x): return x.id == "debris")
	_check(not deb.is_empty() and deb[0].state == "failed", "the debris objective is failed")

	# 8. The campaign: every objective reported; the operation ends on time with a debrief.
	var st := sim.campaign.status()
	_check(st.size() == sim.camp.objectives.size(), "every objective has a state")
	_check(st.all(func(x): return x.state in ["open", "done", "failed"]), "states are open, done or failed")
	sim.campaign.check()
	_check(sim.campaign.over, "after two days the operation is over (%s: %s)" % [sim.campaign.result, sim.campaign.why])
	var db := sim.campaign.debrief()
	_check(db.has("result") and db.objectives.size() == st.size() and is_finite(float(db.days)), "the debrief reports result, objectives and days (%s, %.1f d)" % [db.result, float(db.days)])

	# 9. Save and load (the player's own save file is kept aside and put back).
	var keep := FileAccess.get_file_as_string(SaveGame.PATH) if FileAccess.file_exists(SaveGame.PATH) else ""
	SaveGame.save(sim)
	var back := _world()
	_check(SaveGame.load_into(back), "the save loads")
	_check(_fingerprint(back) == _fingerprint(sim), "into the same world, to the last digit")
	back.advance(Sim.HOUR)
	sim.advance(Sim.HOUR)
	_check(_fingerprint(back) == _fingerprint(sim), "and the two run on alike")
	if keep != "":
		FileAccess.open(SaveGame.PATH, FileAccess.WRITE).store_string(keep)
	else:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveGame.PATH))

	# The command-line runner on this scenario.
	var out := OS.get_user_data_dir().path_join("scenario_test.jsonl")
	var code := OS.execute(OS.get_executable_path(), ["--headless", "--path", ProjectSettings.globalize_path("res://"), "--script", "res://cli/run.gd", "--",
		"--scenario=" + RANGE, "--hours=3", "--step=600", "--out=" + out])
	var lines := FileAccess.get_file_as_string(out).strip_edges().split("\n") if FileAccess.file_exists(out) else PackedStringArray()
	var parsed := Array(lines).map(func(l): return JSON.parse_string(l))
	_check(code == 0 and lines.size() == 20, "the runner exits cleanly with start, 18 steps and end (%d lines)" % lines.size())
	_check(parsed.all(func(x): return x is Dictionary), "every line is a JSON object")
	if parsed.size() >= 2 and parsed[0] is Dictionary and parsed.back() is Dictionary:
		_check(parsed[0].type == "start" and parsed[0].name == "TEST RANGE" and parsed.back().type == "end", "it starts with the scenario's name and ends with a debrief")
	DirAccess.remove_absolute(out)

	# A finished world is freed (no reference cycles keep it).
	var wr: WeakRef = weakref(sim)
	sim = null
	e = null
	k = null
	k2 = null
	p = null
	o = null
	back = null
	h = {}
	lancer = {}
	kv = {}
	kv2 = {}
	_check(wr.get_ref() == null, "a finished world is freed")

	print("%d failed" % fails)
	quit(1 if fails > 0 else 0)
